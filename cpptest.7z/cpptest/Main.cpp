#include "Common.h"

int main(int argc, char * argv[])
{
	using namespace std;

	using namespace std;
	LogService& logService_ = Singleton<LogService>::instance();
	logService_.runPreinit();
	TimeService& timeService_ = Singleton<TimeService>::instance();
	timeService_.runPreinit();
	DbService& dbService_ = Singleton<DbService>::instance();
	dbService_.runPreinit();
	timeService_.startEnd();

	D2SStatement d2SStatement1_;
	S2DStatementPtr s2DStatement1_(new S2DStatement());
	s2DStatement1_->pushStatement(1, "SELECT `name`,`value`,`value1` FROM t_test WHERE `id`=? or `id`=?");
	dbService_.registerStatement(1, s2DStatement1_, &d2SStatement1_);

	S2DPreQueryPtr s2DPreQuery_(new S2DPreQuery(1, 1));
	DbParamPtr dbParam6(new DbParam());
	dbParam6->setInt32(1);
	s2DPreQuery_->pushDbParam(dbParam6);
	DbParamPtr dbParam7(new DbParam());
	dbParam7->setInt32(2);
	s2DPreQuery_->pushDbParam(dbParam7);
	D2SPreQuery d2SPreQuery_(1);
	dbService_.runPreQuery(1, s2DPreQuery_, &d2SPreQuery_);

	dbService_.runStop();
	dbService_.runClear();
	dbService_.runExit();
	cin.get();
	return 0;
}

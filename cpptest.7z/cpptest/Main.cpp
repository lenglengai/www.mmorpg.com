#include "Common.h"

int main(int argc, char * argv[])
{
	using namespace std;

	using namespace std;
	LogService& logService_ = Singleton<LogService>::instance();
	logService_.runPreinit();
	TimeService& timeService_ = Singleton<TimeService>::instance();
	timeService_.runPreinit();
	DbService& dbService_ = Singleton<DbService>::instance();
	dbService_.runPreinit();
	timeService_.startEnd();

	D2SCommand d2SCommand_(1);

	string command_("INSERT INTO t_test(`id`, `name`,`value`,`value1`)VALUES('1', 'zyh','1','1')");
	dbService_.runCommand(1, command_, &d2SCommand_);
	d2SCommand_.runPrint();

	string command_1("INSERT INTO t_test(`id`, `name`,`value`,`value1`)VALUES('2', 'zyh','2','2')");
	dbService_.runCommand(1, command_1, &d2SCommand_);
	d2SCommand_.runPrint();

	string command_2("INSERT INTO t_test(`id`, `name`,`value`,`value1`)VALUES('3', 'zyh','3','3')");
	dbService_.runCommand(1, command_2, &d2SCommand_);
	d2SCommand_.runPrint();

	D2SQuery d2SQuery_(1);
	string query_("SELECT `id`,`name`,`value`,`value1` FROM t_test WHERE `id`=1");
	dbService_.runQuery(1, query_, &d2SQuery_);
	d2SQuery_.runPrint();

	D2SStatement d2SStatement1_;
	S2DStatementPtr s2DStatement1_(new S2DStatement());
	s2DStatement1_->pushStatement(1, "INSERT INTO t_test(`id`,`name`,`value`,`value1`)VALUES(?,?,?,?)");
	dbService_.registerStatement(1, s2DStatement1_, &d2SStatement1_);

	D2SStatement d2SStatement_;
	S2DStatementPtr s2DStatement_(new S2DStatement());
	s2DStatement_->pushStatement(2, "SELECT `name`,`value`,`value1` FROM t_test WHERE `id`=?");
	dbService_.registerStatement(1, s2DStatement_, &d2SStatement_);

	S2DPreCommandPtr s2DPreCommand_(new S2DPreCommand(1, 1));
	DbParamPtr dbParam1(new DbParam());
	dbParam1->setInt32(4);
	s2DPreCommand_->pushDbParam(dbParam1);
	DbParamPtr dbParam2(new DbParam());
	string name_("zyh");
	dbParam2->setString(name_);
	s2DPreCommand_->pushDbParam(dbParam2);
	DbParamPtr dbParam4(new DbParam());
	dbParam4->setInt32(1);
	s2DPreCommand_->pushDbParam(dbParam4);
	DbParamPtr dbParam5(new DbParam());
	dbParam5->setInt32(1);
	s2DPreCommand_->pushDbParam(dbParam5);
	D2SPreCommand d2SPreCommand(1);
	dbService_.runPreCommand(1, s2DPreCommand_, &d2SPreCommand);

	S2DPreQueryPtr s2DPreCommand_(new S2DPreQueryPtr(1, 1));
	DbParamPtr dbParam1(new DbParam());
	dbParam1->setInt32(4);
	s2DPreCommand_->pushDbParam(dbParam1);
	DbParamPtr dbParam2(new DbParam());
	string name_("zyh");
	dbParam2->setString(name_);
	s2DPreCommand_->pushDbParam(dbParam2);
	DbParamPtr dbParam4(new DbParam());
	dbParam4->setInt32(1);
	s2DPreCommand_->pushDbParam(dbParam4);
	DbParamPtr dbParam5(new DbParam());
	dbParam5->setInt32(1);
	s2DPreCommand_->pushDbParam(dbParam5);
	D2SPreQuery d2SPreQuery(1);
	dbService_.runPreCommand(1, d2SPreQuery, &d2SPreCommand);

	dbService_.runStop();
	dbService_.runClear();
	dbService_.runExit();
	cin.get();
	return 0;
}

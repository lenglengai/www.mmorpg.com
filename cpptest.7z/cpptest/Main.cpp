#include "Common.h"

int main ( int argc, char * argv[] )
{
	using namespace std;
	LogService& logService_ = Singleton<LogService>::instance();
	logService_.runPreinit();
	TimeService& timeService_ = Singleton<TimeService>::instance();
	timeService_.runPreinit();
	DbService& dbService_ = Singleton<DbService>::instance();
	dbService_.runPreinit();
	timeService_.startEnd();
	
	D2SStatement d2SStatement_;
	S2DStatementPtr s2DStatement_(new S2DStatement());
	s2DStatement_->pushStatement(1, "INSERT INTO t_test(`id`,`name`,`value`,`value1`)VALUES(?,?,?,?)");
	dbService_.registerStatement(1, s2DStatement_, &d2SStatement_);

	S2DPreCommandPtr s2DPreCommand_(new S2DPreCommand(1, 1));
	DbParamPtr dbParam1(new DbParam());
	dbParam1->setInt32(1);
	s2DPreCommand_->pushDbParam(dbParam1);
	DbParamPtr dbParam2(new DbParam());
	string name_("zyh");
	dbParam2->setString(name_);
	s2DPreCommand_->pushDbParam(dbParam2);
	DbParamPtr dbParam4(new DbParam());
	dbParam4->setInt32(1);
	s2DPreCommand_->pushDbParam(dbParam4);
	DbParamPtr dbParam5(new DbParam());
	dbParam5->setInt32(1);
	s2DPreCommand_->pushDbParam(dbParam5);
	D2SPreCommand d2SPreCommand(1);
	dbService_.runPreCommand(1, s2DPreCommand_, &d2SPreCommand);
	
	dbService_.runStop();
	dbService_.runClear();
	dbService_.runExit();
	std::cin.get();
	return 0;
}

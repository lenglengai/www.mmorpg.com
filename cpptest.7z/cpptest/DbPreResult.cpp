
namespace std {
	
	size_t DbPreResult::SizeForType(MYSQL_FIELD * nField)
	{
		switch (nField->type) 
		{
			case MYSQL_TYPE_TINY:
                return 1;
            case MYSQL_TYPE_SHORT:
                return 2;
            case MYSQL_TYPE_LONG:
            case MYSQL_TYPE_FLOAT:
                return 4;
            case MYSQL_TYPE_DOUBLE:
            case MYSQL_TYPE_LONGLONG:
                return 8;
            case MYSQL_TYPE_TINY_BLOB:
            case MYSQL_TYPE_MEDIUM_BLOB:
            case MYSQL_TYPE_LONG_BLOB:
            case MYSQL_TYPE_BLOB:
            case MYSQL_TYPE_STRING:
            case MYSQL_TYPE_VAR_STRING:
                return field->max_length + 1;
            default:
                return 0;
        }
    }
		
	__i16 DbPreResult::runQuery(D2SReQuery * nD2SReQuery)
	{
		uint32 i = 0;
		MYSQL_FIELD * field_ = mysql_fetch_field(mHandle);
		while (nullptr != field_) {
			size_t size = Field::SizeForType(field);
			m_rBind[i].buffer_type = field_->type;
        m_rBind[i].buffer = malloc(size);
        memset(m_rBind[i].buffer, 0, size);
        m_rBind[i].buffer_length = size;
        m_rBind[i].length = &m_length[i];
        m_rBind[i].is_null = &m_isNull[i];
        m_rBind[i].error = NULL;
        m_rBind[i].is_unsigned = field->flags & UNSIGNED_FLAG;

        ++i;
        field = mysql_fetch_field(m_res);
    }
	
		unsigned long * length_ = nullptr;
		__i16 errorCode_ = Error_::mSucess_;
		MYSQL_ROW rowResult_ = mysql_fetch_row(mHandle);
		while ( nullptr != rowResult_ ) {
			length_ = mysql_fetch_lengths(mHandle));
			if (nullptr == length_) break;
			for (__i16 i = 0; i < _fieldCount; i++) {
				switch (mFieldResult[i].type) {
					case MYSQL_TYPE_TINY:
						{
							errorCode_ = nD2SQuery->runInt8(rowResult_[i], length_[i]);
							if (Error_::mSucess_ != errorCode_) {
								return errorCode_;
							}
						}
						break;
					case MYSQL_TYPE_SHORT:
						{
							errorCode_ = nD2SQuery->runInt16(rowResult_[i], length_[i]);
							if (Error_::mSucess_ != errorCode_) {
								return errorCode_;
							}
						}
						break;
					case MYSQL_TYPE_LONG:
						{
							errorCode_ = nD2SQuery->runInt32(rowResult_[i], length_[i]);
							if (Error_::mSucess_ != errorCode_) {
								return errorCode_;
							}
						}
						break;
					case MYSQL_TYPE_LONGLONG:
						{
							errorCode_ = nD2SQuery->runInt64(rowResult_[i], length_[i]);
							if (Error_::mSucess_ != errorCode_) {
								return errorCode_;
							}
						}
						break;
					case MYSQL_TYPE_FLOAT:
						{
							errorCode_ = nD2SQuery->runFloat(rowResult_[i], length_[i]);
							if (Error_::mSucess_ != errorCode_) {
								return errorCode_;
							}
						}
						break;
					case MYSQL_TYPE_DOUBLE:
						{
							errorCode_ = nD2SQuery->runDouble(rowResult_[i], length_[i]);
							if (Error_::mSucess_ != errorCode_) {
								return errorCode_;
							}
						}
						break;
					case MYSQL_TYPE_STRING:
					case MYSQL_TYPE_VAR_STRING:
						{
							errorCode_ = nD2SQuery->runString(rowResult_[i], length_[i]);
							if (Error_::mSucess_ != errorCode_) {
								return errorCode_;
							}
						}
						break;
					case MYSQL_TYPE_TINY_BLOB:
					case MYSQL_TYPE_MEDIUM_BLOB:
					case MYSQL_TYPE_LONG_BLOB:
					case MYSQL_TYPE_BLOB:
						{
							errorCode_ = nD2SQuery->runBlob(rowResult_[i], length_[i]);
							if (Error_::mSucess_ != errorCode_) {
								return errorCode_;
							}
						}
						break;
					default:
						return DbError_::mNoField_;
				}
			}
		}
		return Error_::mSucess_;
	}
		
	DbPreResult::DbPreResult(MYSQL_STMT * nStmt, MYSQL_RES * nHandle, 
			__i16 nRowCount, __i16 nFieldCount)
		: mHandle (nHandle)
		, mStmt (nStmt)
		, mRowCount (nRowCount)
		, mFieldCount (nFieldCount)
	{
		mBind = new MYSQL_BIND[nFieldCount];
		mIsNull = new my_bool[nFieldCount];
		mLength = new unsigned long[nFieldCount];
		memset(mIsNull, 0, sizeof(my_bool) * nFieldCount);
		memset(mBind, 0, sizeof(MYSQL_BIND) * nFieldCount);
		memset(mLength, 0, sizeof(unsigned long) * nFieldCount);
	}
	
	DbPreResult::~DbPreResult()
	{
		if (nullptr != mHandle) {
			mysql_free_result(mHandle);
		}
		if (nullptr != mStmt) {
			mysql_stmt_free_result(mStmt);
		}
	}
	
}

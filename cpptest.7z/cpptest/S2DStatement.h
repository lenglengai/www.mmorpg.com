#pragma once

namespace std {
	
	class S2DStatement
	{
	public:
		const map<__i32, string>& getStatements() const;
		__i32 getCommandNo() const;
		
		S2DStatement();
		~S2DStatement();
		
	private:
		map<__i32, string> mStatements;
		__i32 mCommandNo;
	};
	typedef shared_ptr<S2DStatement> S2DStatementPtr;
	
}

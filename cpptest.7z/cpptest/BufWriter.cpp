#include "Common.h"

namespace std {
	
	void BufWriter::runPrint()
	{
		std::cout << mPos << std::endl;
	}
	
	__i8 BufWriter::runInt8(char * nValue, __i16 nLength)
	{
		__i8 value_ = __convert<char *, __i8>(nValue);
		return this->runCopy(value_);
	}
	
	__i8 BufWriter::runInt16(char * nValue, __i16 nLength)
	{
		__i16 value_ = __convert<char *, __i16>(nValue);
		return this->runCopy(value_);
	}
	
	__i8 BufWriter::runInt32(char * nValue, __i16 nLength)
	{
		__i32 value_ = __convert<char *, __i32>(nValue);
		return this->runCopy(value_);
	}
	
	__i8 BufWriter::runInt64(char * nValue, __i16 nLength)
	{
		__i64 value_ = __convert<char *, __i64>(nValue);
		return this->runCopy(value_);
	}
	
	__i8 BufWriter::runFloat(char * nValue, __i16 nLength)
	{
		float value_ = __convert<char *, float>(nValue);
		return this->runCopy(value_);
	}
	
	__i8 BufWriter::runDouble(char * nValue, __i16 nLength)
	{
		double value_ = __convert<char *, double>(nValue);
		return this->runCopy(value_);
	}
	
	__i8 BufWriter::runString(char * nValue, __i16 nLength)
	{
		return this->runCopy(nValue, nLength);
	}
	
	__i8 BufWriter::runBlob(char * nValue, __i16 nLength)
	{
		return this->runCopy(nValue, nLength);
	}
	
	__i8 BufWriter::runCopy(char * nValue, __i16 nLength)
	{
		__i8 errorCode_ = this->runInt16(nValue, nLength);
		if ( DbError_::mSucess_ != errorCode_ ) {
			return errorCode_;
		}
		if ( (mPos + nLength) > BUFSIZE ) {
			return DbError_::mOverflow_;
		}
		memcpy( (mBuffer + mPos), nValue, nLength );
		mPos += nLength;
		return DbError_::mSucess_;
	}
	
	void BufWriter::runClear()
	{
		memset(mBuffer, 0, sizeof(mBuffer));
		mPos = 0;
	}
	
	BufWriter::BufWriter()
	{
		this->runClear();
	}
	
	BufWriter::~BufWriter()
	{
		this->runClear();
	}
	
}

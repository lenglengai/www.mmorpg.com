#include "Common.h"

namespace std {
	
	void BufWriter::runPrint()
	{
		std::cout << mPos << std::endl;
	}
	
	__i8 BufWriter::runInt8(void * nValue, __i16 nLength)
	{
		__i8 value_ = __convert<char *, __i8>(nValue, ConvertType_::mBinary_);
		return this->runCopy(value_);
	}
	
	__i8 BufWriter::runInt16(void * nValue, __i16 nLength)
	{
		__i16 value_ = __convert<char *, __i16>(nValue, ConvertType_::mBinary_);
		return this->runCopy(value_);
	}
	
	__i8 BufWriter::runInt32(void * nValue, __i16 nLength)
	{
		__i32 value_ = __convert<char *, __i32>(nValue, ConvertType_::mBinary_);
		return this->runCopy(value_);
	}
	
	__i8 BufWriter::runInt64(void * nValue, __i16 nLength)
	{
		__i64 value_ = __convert<char *, __i64>(nValue, ConvertType_::mBinary_);
		return this->runCopy(value_);
	}
	
	__i8 BufWriter::runFloat(void * nValue, __i16 nLength)
	{
		float value_ = __convert<char *, float>(nValue, ConvertType_::mBinary_);
		return this->runCopy(value_);
	}
	
	__i8 BufWriter::runDouble(void * nValue, __i16 nLength)
	{
		double value_ = __convert<char *, double>(nValue, ConvertType_::mBinary_);
		return this->runCopy(value_);
	}
	
	__i8 BufWriter::runString(void * nValue, __i16 nLength)
	{
		return this->runCopy(nValue, nLength);
	}
	
	__i8 BufWriter::runBlob(void * nValue, __i16 nLength)
	{
		return this->runCopy(nValue, nLength);
	}
	
	__i8 BufWriter::runCopy(void * nValue, __i16 nLength)
	{
		if ( (mPos + nLength) > BUFSIZE ) {
			return DbError_::mOverflow_;
		}
		memcpy( (mBuffer + mPos), nValue, nLength );
		mPos += nLength;
		return DbError_::mSucess_;
	}
	
	void BufWriter::runClear()
	{
		memset(mBuffer, 0, sizeof(mBuffer));
		mPos = 0;
	}
	
	BufWriter::BufWriter()
	{
		this->runClear();
	}
	
	BufWriter::~BufWriter()
	{
		this->runClear();
	}
	
}

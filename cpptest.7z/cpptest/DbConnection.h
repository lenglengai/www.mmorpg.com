#pragma once

namespace std {
	
	class DataBase;
	class DbConnection : noncopyable
	{
	public:
		__i8 runCommand(const string& nCommand, D2SCommand * nD2SCommand);
		__i8 runQuery(const string& nQuery, D2SQuery * nD2SQuery);
		
		bool runAcquire();
		void runRecycle();
		
		bool runConnect();
		void runDisconnect();
		
	private:
		__i8 runCommand(const char * nCommand, __i16 nLength);
		
		void runActivate(bool nForce = false);
		bool internalConnect();
		void internalDisconnect();
		
		//__i8 runPreStatement();
		
	public:
		explicit DbConnection(DataBase * nDataBase);
		~DbConnection();
		
	private:
		//map<__i32, DbStatementPtr> mDbStatements;
		
		DataBase * mDataBase;
		__i32 mTimeStamp;
		bool mConnected;
		bool mBusy;
		
		MYSQL mHandle;
	};
	typedef shared_ptr<DbConnection> DbConnectionPtr;
	
}

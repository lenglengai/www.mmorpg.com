#include "Common.h"

namespace std {
	
	const map<__i32, string>& S2DStatement::getStatements() const
	{
		return mStatements;
	}
	
	__i32 S2DStatement::getCommandNo() const
	{
		return mCommandNo;
	}
	
	S2DStatement::S2DStatement()
		: mCommandNo (0)
	{
		mStatements.clear();
	}
	
	S2DStatement::~S2DStatement()
	{
		mStatements.clear();
		mCommandNo = 0;
	}
	
}

#pragma once

namespace std {

	class DbPreResult : noncopyable
	{
	public:
		__i16 runQuery(D2SReQuery * nD2SReQuery);
		
		DbPreResult(MYSQL_STMT * nStmt, MYSQL_RES * nHandle, 
			__i16 nRowCount, __i16 nFieldCount);
		~DbPreResult();
		
	private:
	    my_bool * mIsNull;
        unsigned long * mLength;
		MYSQL_BIND * mBind;
		MYSQL_STMT * mStmt;
		MYSQL_RES * mHandle;
		__i16 mRowCount;
		__i16 mFieldCount;
	};
	
}
#endif

#pragma once

namespace std {
	
	class DbService : noncopyable
	{
	public:
		__i8 runCommand(__i32 nDataBaseId, const string& nCommand, D2SCommand * nD2SCommand);
		__i8 runQuery(__i32 nDataBaseId, const string& nQuery, D2SQuery * nD2SQuery);
		__i8 registerStatement(__i32 nDataBaseId, S2DStatementPtr& nS2DStatement, D2SStatement * nD2SStatement);
		
		bool runPreinit();
		void runStop();
		void runClear();
		void runExit();
		
		DbService();
		~DbService();
		
	private:
		map<__i32, DataBasePtr> mDataBases;
	};
	
}

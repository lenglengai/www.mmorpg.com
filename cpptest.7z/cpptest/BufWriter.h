#pragma once

#define BUFSIZE 1024
namespace std {
	
	class BufWriter : noncopyable
	{
	public:
		void runPrint();
		__i8 runInt8(void * nValue, __i16 nLength);
		__i8 runInt16(void * nValue, __i16 nLength);
		__i8 runInt32(void * nValue, __i16 nLength);
		__i8 runInt64(void * nValue, __i16 nLength);
		__i8 runFloat(void * nValue, __i16 nLength);
		__i8 runDouble(void * nValue, __i16 nLength);
		__i8 runString(void * nValue, __i16 nLength);
		__i8 runBlob(void * nValue, __i16 nLength);
		
		template<typename __t>
		__i8 runCopy(__t& nT) {
			if ( (mPos + sizeof(__t)) > BUFSIZE ) {
				return DbError_::mOverflow_;
			}
			memcpy( (mBuffer + mPos), &nT, sizeof(__t) );
			mPos += sizeof(__t);
			return DbError_::mSucess_;
		}
		__i8 runCopy(void * nValue, __i16 nLength);
		void runClear();
		
		BufWriter();
		~BufWriter();
		
	private:
		char mBuffer[BUFSIZE];
		__i16 mPos;
	};
	
}

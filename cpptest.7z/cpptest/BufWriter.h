#pragma once

#define BUFSIZE 1024
namespace std {
	
	class BufWriter : noncopyable
	{
	public:
		void runPrint();
		__i8 runInt8(char * nValue, __i16 nLength);
		__i8 runInt16(char * nValue, __i16 nLength);
		__i8 runInt32(char * nValue, __i16 nLength);
		__i8 runInt64(char * nValue, __i16 nLength);
		__i8 runFloat(char * nValue, __i16 nLength);
		__i8 runDouble(char * nValue, __i16 nLength);
		__i8 runString(char * nValue, __i16 nLength);
		__i8 runBlob(char * nValue, __i16 nLength);
		
		template<typename __t>
		__i8 runCopy(__t& nT) {
			if ( (mPos + sizeof(__t)) > BUFSIZE ) {
				return DbError_::mOverflow_;
			}
			memcpy( (mBuffer + mPos), &nT, sizeof(__t) );
			mPos += sizeof(__t);
			return DbError_::mSucess_;
		}
		__i8 runCopy(char * nValue, __i16 nLength);
		void runClear();
		
		BufWriter();
		~BufWriter();
		
	private:
		char mBuffer[BUFSIZE];
		__i16 mPos;
	};
	
}

#include "Common.h"

namespace std {
	
	void D2SPreQuery::setErrorCode(__i8 nErrorCode)
	{
		mErrorCode = nErrorCode;
	}
	
	void D2SPreQuery::setRowCount(__i16 nRowCount)
	{
		mRowCount = nRowCount;
	}

	D2SPreQuery::D2SPreQuery(__i32 nCommandNo)
		: mCommandNo (nCommandNo)
		, mErrorCode (DbError_::mError_)
		, mRowCount (0)
	{
	}
	
	D2SPreQuery::~D2SPreQuery()
	{
		mCommandNo = 0;
		mErrorCode = DbError_::mError_;
		mRowCount = 0;
	}
	
}

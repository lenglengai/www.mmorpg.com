#pragma once

#ifdef APIEXPORT
#define __funapi __declspec(dllexport)
#else
#define __funapi
#endif

#if defined(_WIN32) ||  defined(_WIN64)
#define __WINDOW__
#endif

#ifdef __WINDOW__
#define __FUN__ __FUNCTION__
#else
#define __FUN__ __PRETTY_FUNCTION__
#endif

#define STARTYEAR 2015
#define STARTMONTH 1
#define STARTDAY 1

#define ENDYEAR 2015
#define ENDMONTH 6
#define ENDDAY 1

#define INITYEAR 2015
#define INITMONTH 1
#define INITDAY 1

#define VERNAME "release"

typedef char __i8;
typedef short __i16;
typedef long __i32;
#ifdef __WINDOW__
typedef __int64 __i64;
#else
typedef long long __i64;
#endif

#include <string>
#include <list>
#include <vector>
#include <map>
#include <set>
#include <stack>
#include <queue>
#include <deque>
#include <memory>
#include <functional>
#include <mutex>
#include <atomic>
#include <chrono>
#include <thread>
#include <random>
#include <typeinfo>
#include <iostream>
#include <sstream>

#ifdef __WINDOW__
#pragma warning( push )
#pragma warning( disable : 4819 )
#endif
#include <boost/format.hpp>
#ifdef __WINDOW__
#pragma warning( pop )
#endif

#include <errmsg.h>
#include <mysql.h>

#include "noncopyable.h"
#include "singleton.h"
#include "default.h"
#include "convert.h"
#include "LogService.h"
#include "TimeService.h"
#include "DbError_.h"
#include "BufWriter.h"
#include "D2SCommand.h"
#include "D2SQuery.h"
#include "DbParam.h"
#include "S2DStatement.h"
#include "D2SStatement.h"
#include "S2DPreCommand.h"
#include "D2SPreCommand.h"
#include "DbResult.h"
#include "DbStatement.h"
#include "DbConnection.h"
#include "DataBase.h"
#include "DbService.h"
